package com.sitemuster.app

data class WorkerRecord(
    val id: String,
    var name: String,
    var workType: String,
    var dailyRate: Double,
    val hazriByDay: MutableMap<Int, Double> = mutableMapOf(),
    val advanceByDay: MutableMap<Int, Double> = mutableMapOf(),
    var settledAmount: Double = 0.0
) {
    fun totalHazri(): Double = hazriByDay.values.sum()
    fun totalAdvance(): Double = advanceByDay.values.sum()
    fun grossPay(): Double = totalHazri() * dailyRate
    fun balanceLeft(): Double = (grossPay() - totalAdvance() - settledAmount).coerceAtLeast(0.0)
}

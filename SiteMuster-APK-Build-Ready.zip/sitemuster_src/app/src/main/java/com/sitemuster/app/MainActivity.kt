package com.sitemuster.app

import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButton
import java.text.DateFormatSymbols
import java.text.NumberFormat
import java.util.Calendar
import java.util.Locale
import java.util.UUID

class MainActivity : AppCompatActivity() {

    private lateinit var repo: MusterRepository
    private lateinit var adapter: WorkerAdapter

    private var currentYear: Int = 2026
    private var currentMonthZeroBased: Int = Calendar.NOVEMBER
    private var selectedDay: Int = 21
    private var viewMode: Int = 0 // 0 = Daily Hazri, 1 = Month Pay, 2 = Advances
    private var workers: MutableList<WorkerRecord> = mutableListOf()

    private lateinit var tvSiteName: TextView
    private lateinit var tvMonthYear: TextView
    private lateinit var tvTotalEarned: TextView
    private lateinit var tvTotalAdvance: TextView
    private lateinit var tvTotalBalance: TextView
    private lateinit var dailyDateBar: View
    private lateinit var tvSelectedDate: TextView
    private lateinit var rvWorkers: RecyclerView
    private lateinit var bottomNav: BottomNavigationView

    private val currencyFmt = NumberFormat.getCurrencyInstance(Locale("en", "IN")).apply {
        maximumFractionDigits = 0
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        repo = MusterRepository(this)
        val cal = Calendar.getInstance()
        currentYear = cal.get(Calendar.YEAR)
        currentMonthZeroBased = cal.get(Calendar.MONTH)
        selectedDay = cal.get(Calendar.DAY_OF_MONTH).coerceAtMost(repo.daysInMonth(currentYear, currentMonthZeroBased))

        bindViews()
        setupListeners()
        loadMonthData()
    }

    private fun bindViews() {
        tvSiteName = findViewById(R.id.tvSiteName)
        tvMonthYear = findViewById(R.id.tvMonthYear)
        tvTotalEarned = findViewById(R.id.tvTotalEarned)
        tvTotalAdvance = findViewById(R.id.tvTotalAdvance)
        tvTotalBalance = findViewById(R.id.tvTotalBalance)
        dailyDateBar = findViewById(R.id.dailyDateBar)
        tvSelectedDate = findViewById(R.id.tvSelectedDate)
        rvWorkers = findViewById(R.id.rvWorkers)
        bottomNav = findViewById(R.id.bottomNav)

        rvWorkers.layoutManager = LinearLayoutManager(this)
        adapter = WorkerAdapter(
            items = workers,
            selectedDay = selectedDay,
            viewMode = viewMode,
            onHazriChanged = { worker, day, value ->
                worker.hazriByDay[day] = value
                persistAndRefresh()
            },
            onAdvanceAdded = { worker, day, amount ->
                if (amount < 0) {
                    showCustomAdvanceDialog(worker, day)
                } else {
                    val prev = worker.advanceByDay[day] ?: 0.0
                    worker.advanceByDay[day] = prev + amount
                    persistAndRefresh()
                }
            },
            onEditInternal = { worker -> showAddOrEditWorkerDialog(worker) },
            onSeparateView = { worker -> showWorkerSeparateSheetDialog(worker) },
            onSettleWorker = { worker -> showSettleDialog(worker) }
        )
        rvWorkers.adapter = adapter
    }

    private fun setupListeners() {
        findViewById<MaterialButton>(R.id.btnEditSite).setOnClickListener {
            val input = EditText(this).apply {
                setText(repo.siteName)
                setSelection(text.length)
            }
            AlertDialog.Builder(this)
                .setTitle("Edit Construction Site")
                .setView(input)
                .setPositiveButton("Save") { _, _ ->
                    repo.siteName = input.text.toString()
                    refreshHeader()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        findViewById<MaterialButton>(R.id.btnPrevMonth).setOnClickListener {
            shiftMonth(-1)
        }

        findViewById<MaterialButton>(R.id.btnNextMonth).setOnClickListener {
            shiftMonth(1)
        }

        findViewById<MaterialButton>(R.id.btnCopyRoster).setOnClickListener {
            val copied = repo.copyRosterFromPreviousMonth(currentYear, currentMonthZeroBased)
            workers = repo.loadWorkers(currentYear, currentMonthZeroBased)
            persistAndRefresh()
            Toast.makeText(
                this,
                if (copied > 0) "Copied $copied worker(s) from previous month" else "Crew already up to date",
                Toast.LENGTH_SHORT
            ).show()
        }

        findViewById<MaterialButton>(R.id.btnPrevDay).setOnClickListener {
            if (selectedDay > 1) {
                selectedDay--
                refreshAll()
            }
        }

        findViewById<MaterialButton>(R.id.btnNextDay).setOnClickListener {
            val maxDays = repo.daysInMonth(currentYear, currentMonthZeroBased)
            if (selectedDay < maxDays) {
                selectedDay++
                refreshAll()
            }
        }

        findViewById<MaterialButton>(R.id.btnAddWorker).setOnClickListener {
            showAddOrEditWorkerDialog(null)
        }

        bottomNav.setOnItemSelectedListener { item ->
            viewMode = when (item.itemId) {
                R.id.menu_daily -> 0
                R.id.menu_month -> 1
                R.id.menu_advance -> 2
                else -> 0
            }
            dailyDateBar.visibility = if (viewMode == 0) View.VISIBLE else View.GONE
            refreshAll()
            true
        }
    }

    private fun shiftMonth(delta: Int) {
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, currentYear)
            set(Calendar.MONTH, currentMonthZeroBased)
            set(Calendar.DAY_OF_MONTH, 1)
            add(Calendar.MONTH, delta)
        }
        currentYear = cal.get(Calendar.YEAR)
        currentMonthZeroBased = cal.get(Calendar.MONTH)
        selectedDay = selectedDay.coerceAtMost(repo.daysInMonth(currentYear, currentMonthZeroBased))
        loadMonthData()
    }

    private fun loadMonthData() {
        workers = repo.loadWorkers(currentYear, currentMonthZeroBased)
        refreshAll()
    }

    private fun persistAndRefresh() {
        repo.saveWorkers(currentYear, currentMonthZeroBased, workers)
        refreshAll()
    }

    private fun refreshAll() {
        refreshHeader()
        adapter.updateData(workers, selectedDay, viewMode)
    }

    private fun refreshHeader() {
        tvSiteName.text = "Site: ${repo.siteName}"
        val monthName = DateFormatSymbols(Locale.ENGLISH).months[currentMonthZeroBased]
        tvMonthYear.text = "$monthName $currentYear"
        tvSelectedDate.text = "Day $selectedDay"

        val totalEarned = workers.sumOf { it.grossPay() }
        val totalAdv = workers.sumOf { it.totalAdvance() }
        val totalBal = workers.sumOf { it.balanceLeft() }

        tvTotalEarned.text = currencyFmt.format(totalEarned)
        tvTotalAdvance.text = currencyFmt.format(totalAdv)
        tvTotalBalance.text = currencyFmt.format(totalBal)
    }

    private fun showAddOrEditWorkerDialog(existing: WorkerRecord?) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_edit_worker, null)
        val etName = dialogView.findViewById<EditText>(R.id.etWorkerName)
        val etType = dialogView.findViewById<EditText>(R.id.etWorkType)
        val etRate = dialogView.findViewById<EditText>(R.id.etDailyRate)

        if (existing != null) {
            etName.setText(existing.name)
            etType.setText(existing.workType)
            etRate.setText(existing.dailyRate.toString())
        }

        val builder = AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Add Worker" else "Edit Worker Internally")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val name = etName.text.toString().trim().ifEmpty { "Worker" }
                val type = etType.text.toString().trim().ifEmpty { "Helper" }
                val rate = etRate.text.toString().toDoubleOrNull()?.coerceAtLeast(0.0) ?: 500.0

                if (existing == null) {
                    workers.add(
                        WorkerRecord(
                            id = UUID.randomUUID().toString(),
                            name = name,
                            workType = type,
                            dailyRate = rate
                        )
                    )
                } else {
                    existing.name = name
                    existing.workType = type
                    existing.dailyRate = rate
                }
                persistAndRefresh()
            }
            .setNegativeButton("Cancel", null)

        if (existing != null) {
            builder.setNeutralButton("Delete") { _, _ ->
                workers.removeAll { it.id == existing.id }
                persistAndRefresh()
            }
        }

        builder.show()
    }

    private fun showCustomAdvanceDialog(worker: WorkerRecord, day: Int) {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            hint = "Enter advance amount (₹)"
        }
        AlertDialog.Builder(this)
            .setTitle("${worker.name} — Day $day Advance")
            .setView(input)
            .setPositiveButton("Add") { _, _ ->
                val amt = input.text.toString().toDoubleOrNull() ?: 0.0
                if (amt > 0.0) {
                    worker.advanceByDay[day] = (worker.advanceByDay[day] ?: 0.0) + amt
                    persistAndRefresh()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showWorkerSeparateSheetDialog(worker: WorkerRecord) {
        val maxDays = repo.daysInMonth(currentYear, currentMonthZeroBased)
        val lines = StringBuilder()
        lines.append("Role: ${worker.workType} | Rate: ${currencyFmt.format(worker.dailyRate)}/day
")
        lines.append("Total Hazri: ${String.format(Locale.US, "%.2f", worker.totalHazri())} days
")
        lines.append("Gross Pay: ${currencyFmt.format(worker.grossPay())}
")
        lines.append("Advance: ${currencyFmt.format(worker.totalAdvance())} | Settled: ${currencyFmt.format(worker.settledAmount)}
")
        lines.append("Balance Left: ${currencyFmt.format(worker.balanceLeft())}

")
        lines.append("Daily Log (Tap a day to edit):
")

        val dayLabels = (1..maxDays).map { d ->
            val h = worker.hazriByDay[d] ?: 0.0
            val a = worker.advanceByDay[d] ?: 0.0
            "Day $d: Hazri ${String.format(Locale.US, "%.2f", h)} | Adv ${currencyFmt.format(a)}"
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("${worker.name} — Full Month Sheet")
            .setMessage(lines.toString())
            .setItems(dayLabels) { _, idx ->
                val clickedDay = idx + 1
                showDayEditorDialog(worker, clickedDay)
            }
            .setPositiveButton("Close", null)
            .show()
    }

    private fun showDayEditorDialog(worker: WorkerRecord, day: Int) {
        val presets = arrayOf("0 (Absent)", "0.5 (Half)", "1 (Full)", "1.5 (OT)", "2.25", "2.5", "2.75", "3", "3.25", "3.5", "3.75")
        val values = doubleArrayOf(0.0, 0.5, 1.0, 1.5, 2.25, 2.5, 2.75, 3.0, 3.25, 3.5, 3.75)
        AlertDialog.Builder(this)
            .setTitle("${worker.name} — Day $day Hazri")
            .setItems(presets) { _, which ->
                worker.hazriByDay[day] = values[which]
                persistAndRefresh()
                showWorkerSeparateSheetDialog(worker)
            }
            .setNegativeButton("Back") { _, _ -> showWorkerSeparateSheetDialog(worker) }
            .show()
    }

    private fun showSettleDialog(worker: WorkerRecord) {
        val bal = worker.balanceLeft()
        if (bal <= 0.0) {
            Toast.makeText(this, "${worker.name} has zero balance left", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Settle / Mark Paid")
            .setMessage("Mark ${currencyFmt.format(bal)} as paid to ${worker.name}?")
            .setPositiveButton("Mark Paid") { _, _ ->
                worker.settledAmount += bal
                persistAndRefresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}

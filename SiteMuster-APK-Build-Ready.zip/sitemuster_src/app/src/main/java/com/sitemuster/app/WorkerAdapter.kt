package com.sitemuster.app

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import java.text.NumberFormat
import java.util.Locale

class WorkerAdapter(
    private var items: List<WorkerRecord>,
    private var selectedDay: Int,
    private var viewMode: Int, // 0 = Daily Hazri, 1 = Month Pay, 2 = Advances
    private val onHazriChanged: (WorkerRecord, Int, Double) -> Unit,
    private val onAdvanceAdded: (WorkerRecord, Int, Double) -> Unit,
    private val onEditInternal: (WorkerRecord) -> Unit,
    private val onSeparateView: (WorkerRecord) -> Unit,
    private val onSettleWorker: (WorkerRecord) -> Unit
) : RecyclerView.Adapter<WorkerAdapter.WorkerViewHolder>() {

    private val quarterSteps = listOf(2.25, 2.5, 2.75, 3.0, 3.25, 3.5, 3.75)
    private val currencyFmt = NumberFormat.getCurrencyInstance(Locale("en", "IN")).apply {
        maximumFractionDigits = 0
    }

    fun updateData(newItems: List<WorkerRecord>, day: Int, mode: Int) {
        items = newItems
        selectedDay = day
        viewMode = mode
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WorkerViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_worker_card, parent, false)
        return WorkerViewHolder(view)
    }

    override fun onBindViewHolder(holder: WorkerViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class WorkerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvName: TextView = itemView.findViewById(R.id.tvWorkerName)
        private val tvMeta: TextView = itemView.findViewById(R.id.tvWorkerMeta)
        private val tvBalance: TextView = itemView.findViewById(R.id.tvBalanceLeft)
        private val tvMonthStats: TextView = itemView.findViewById(R.id.tvMonthStats)
        private val dailySection: View = itemView.findViewById(R.id.dailyControlsSection)
        private val tvTodayHazri: TextView = itemView.findViewById(R.id.tvTodayHazriLabel)
        private val btnFull: MaterialButton = itemView.findViewById(R.id.btnFull)
        private val btnHalf: MaterialButton = itemView.findViewById(R.id.btnHalf)
        private val btnOt: MaterialButton = itemView.findViewById(R.id.btnOt)
        private val btnAbsent: MaterialButton = itemView.findViewById(R.id.btnAbsent)
        private val quarterContainer: LinearLayout = itemView.findViewById(R.id.quarterHazriContainer)
        private val tvDayAdvance: TextView = itemView.findViewById(R.id.tvDayAdvance)
        private val btnAdv100: MaterialButton = itemView.findViewById(R.id.btnAdv100)
        private val btnAdv200: MaterialButton = itemView.findViewById(R.id.btnAdv200)
        private val btnAdvCustom: MaterialButton = itemView.findViewById(R.id.btnAdvCustom)
        private val btnEditInternal: MaterialButton = itemView.findViewById(R.id.btnEditInternal)
        private val btnSeparateView: MaterialButton = itemView.findViewById(R.id.btnSeparateView)
        private val btnSettle: MaterialButton = itemView.findViewById(R.id.btnSettle)

        fun bind(worker: WorkerRecord) {
            tvName.text = worker.name
            tvMeta.text = "${worker.workType} • ${currencyFmt.format(worker.dailyRate)}/day"

            val bal = worker.balanceLeft()
            tvBalance.text = currencyFmt.format(bal)
            tvBalance.setTextColor(if (bal > 0.0) Color.parseColor("#047857") else Color.parseColor("#6B7280"))

            tvMonthStats.text = String.format(
                Locale.US,
                "Month: %.2f days • Earned %s • Advance %s",
                worker.totalHazri(),
                currencyFmt.format(worker.grossPay()),
                currencyFmt.format(worker.totalAdvance())
            )

            dailySection.visibility = if (viewMode == 0) View.VISIBLE else View.GONE

            val currentDayHazri = worker.hazriByDay[selectedDay] ?: 0.0
            tvTodayHazri.text = String.format(Locale.US, "Day %d Hazri: %.2f", selectedDay, currentDayHazri)

            btnFull.setOnClickListener { onHazriChanged(worker, selectedDay, 1.0) }
            btnHalf.setOnClickListener { onHazriChanged(worker, selectedDay, 0.5) }
            btnOt.setOnClickListener { onHazriChanged(worker, selectedDay, 1.5) }
            btnAbsent.setOnClickListener { onHazriChanged(worker, selectedDay, 0.0) }

            quarterContainer.removeAllViews()
            for (q in quarterSteps) {
                val chipBtn = MaterialButton(
                    itemView.context,
                    null,
                    com.google.android.material.R.attr.materialButtonOutlinedStyle
                ).apply {
                    text = if (q % 1.0 == 0.0) q.toInt().toString() else q.toString()
                    textSize = 12f
                    minWidth = 0
                    minimumWidth = 0
                    setPadding(24, 0, 24, 0)
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        96
                    ).apply {
                        marginEnd = 12
                    }
                    setOnClickListener { onHazriChanged(worker, selectedDay, q) }
                }
                quarterContainer.addView(chipBtn)
            }

            val dayAdv = worker.advanceByDay[selectedDay] ?: 0.0
            tvDayAdvance.text = "Day $selectedDay Advance: ${currencyFmt.format(dayAdv)}"

            btnAdv100.setOnClickListener { onAdvanceAdded(worker, selectedDay, 100.0) }
            btnAdv200.setOnClickListener { onAdvanceAdded(worker, selectedDay, 200.0) }
            btnAdvCustom.setOnClickListener { onAdvanceAdded(worker, selectedDay, -1.0) }

            btnEditInternal.setOnClickListener { onEditInternal(worker) }
            btnSeparateView.setOnClickListener { onSeparateView(worker) }
            btnSettle.setOnClickListener { onSettleWorker(worker) }
        }
    }
}

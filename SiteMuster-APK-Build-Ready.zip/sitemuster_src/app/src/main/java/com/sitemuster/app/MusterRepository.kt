package com.sitemuster.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

class MusterRepository(context: Context) {
    private val prefs = context.getSharedPreferences("sitemuster_prefs_v1", Context.MODE_PRIVATE)

    var siteName: String
        get() = prefs.getString("site_name", "Kalyan School Expansion") ?: "Kalyan School Expansion"
        set(value) = prefs.edit().putString("site_name", value.ifBlank { "Construction Site" }).apply()

    fun monthKey(year: Int, monthZeroBased: Int): String = "$year-${monthZeroBased + 1}"

    fun daysInMonth(year: Int, monthZeroBased: Int): Int {
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, monthZeroBased)
            set(Calendar.DAY_OF_MONTH, 1)
        }
        return cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    }

    fun loadWorkers(year: Int, monthZeroBased: Int): MutableList<WorkerRecord> {
        val key = "workers_${monthKey(year, monthZeroBased)}"
        val raw = prefs.getString(key, null)
        if (raw == null) {
            return if (prefs.getBoolean("seeded_once", false)) {
                mutableListOf()
            } else {
                prefs.edit().putBoolean("seeded_once", true).apply()
                val defaults = mutableListOf(
                    WorkerRecord("w1", "Ramesh Kumar", "Mason (Mistri)", 850.0),
                    WorkerRecord("w2", "Sunil Yadav", "Helper (Mazdoor)", 550.0),
                    WorkerRecord("w3", "Anita Devi", "Helper (Mazdoor)", 550.0)
                )
                saveWorkers(year, monthZeroBased, defaults)
                defaults
            }
        }
        return parseWorkersJson(raw)
    }

    fun saveWorkers(year: Int, monthZeroBased: Int, workers: List<WorkerRecord>) {
        val arr = JSONArray()
        for (w in workers) {
            val obj = JSONObject().apply {
                put("id", w.id)
                put("name", w.name)
                put("workType", w.workType)
                put("dailyRate", w.dailyRate)
                put("settledAmount", w.settledAmount)

                val hazriObj = JSONObject()
                w.hazriByDay.forEach { (d, v) -> hazriObj.put(d.toString(), v) }
                put("hazri", hazriObj)

                val advObj = JSONObject()
                w.advanceByDay.forEach { (d, v) -> advObj.put(d.toString(), v) }
                put("advance", advObj)
            }
            arr.put(obj)
        }
        prefs.edit().putString("workers_${monthKey(year, monthZeroBased)}", arr.toString()).apply()
    }

    fun copyRosterFromPreviousMonth(targetYear: Int, targetMonthZeroBased: Int): Int {
        val prevCal = Calendar.getInstance().apply {
            set(Calendar.YEAR, targetYear)
            set(Calendar.MONTH, targetMonthZeroBased)
            add(Calendar.MONTH, -1)
        }
        val prevWorkers = loadWorkers(prevCal.get(Calendar.YEAR), prevCal.get(Calendar.MONTH))
        if (prevWorkers.isEmpty()) return 0

        val current = loadWorkers(targetYear, targetMonthZeroBased)
        val existingIds = current.map { it.id }.toSet()
        var added = 0
        for (pw in prevWorkers) {
            if (pw.id !in existingIds) {
                current.add(
                    WorkerRecord(
                        id = pw.id,
                        name = pw.name,
                        workType = pw.workType,
                        dailyRate = pw.dailyRate
                    )
                )
                added++
            }
        }
        saveWorkers(targetYear, targetMonthZeroBased, current)
        return added
    }

    private fun parseWorkersJson(raw: String): MutableList<WorkerRecord> {
        val result = mutableListOf<WorkerRecord>()
        val arr = JSONArray(raw)
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            val hazriMap = mutableMapOf<Int, Double>()
            obj.optJSONObject("hazri")?.let { hObj ->
                hObj.keys().forEach { k ->
                    k.toIntOrNull()?.let { day -> hazriMap[day] = hObj.optDouble(k, 0.0) }
                }
            }
            val advMap = mutableMapOf<Int, Double>()
            obj.optJSONObject("advance")?.let { aObj ->
                aObj.keys().forEach { k ->
                    k.toIntOrNull()?.let { day -> advMap[day] = aObj.optDouble(k, 0.0) }
                }
            }
            result.add(
                WorkerRecord(
                    id = obj.optString("id", "w_$i"),
                    name = obj.optString("name", "Worker"),
                    workType = obj.optString("workType", "Helper"),
                    dailyRate = obj.optDouble("dailyRate", 500.0),
                    hazriByDay = hazriMap,
                    advanceByDay = advMap,
                    settledAmount = obj.optDouble("settledAmount", 0.0)
                )
            )
        }
        return result
    }
}

SiteMuster - Android APK Build Instructions

The project currently contains Android source code, not a compiled APK.


OPTION 1 (recommended): Build APK automatically on GitHub
1. Create a new GitHub repository.
2. Upload the contents of this project ZIP to the repository (keep the .github folder).
3. Open the repository's Actions tab.
4. Select "Build SiteMuster APK" and press "Run workflow" (if it isn't triggered by a push).
5. When the run succeeds, open the completed workflow run and download the
   "SiteMuster-debug-apk" artifact. It contains app-debug.apk.


OPTION 2: Android Studio
1. Open the project folder in Android Studio.
2. Allow Gradle Sync to complete.
3. Select Build > Build APK(s).
4. Find the debug APK at:
   app/build/outputs/apk/debug/app-debug.apk

Requirements: Android SDK platform 35 and Java 17. The project uses Gradle 8.9
and Android Gradle Plugin 8.7.2.
